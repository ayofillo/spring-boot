# Deploying Micro-services

## Pre-deployment steps:
- Add user `vms-ms-user`
    - `sudo useradd vms-ms-user`
    -  `sudo passwd vms-ms-user`
        - pwd : vmsms1234
    - `chown -R vms-ms-user:vms-ms-user vms-ms`
- Copy services from `deployment/service/*` to `/etc/systemd/system/*` folder.
- Create folder `/opt/vms-ms`
- Copy `deployment/scripts` folder into `/opt/vms-ms/scripts`
    - Update all `start*.sh` scripts with proper --PROFILE value e.g. --PROFILE=qab in QA-B server.
- Copy `config` folder into `/opt/vms-ms/configs`
    - Make sure that all environment specific properties e.g. database details are correct in respective properties files e.g. application-qab.properties.

## Deployment steps:
- Copy micro services jars into `/opt/vms-ms/apps`
    - rename jars as
        - vms-otp.jar
        - vms-event-processing.jar
- Start micro services
    - `systemctl start vms-otp.service`
    - `systemctl start vms-event-processing.service`
- Check service status
    - `systemctl status vms-otp.service`
    - `systemctl status vms-event-processing.service`
- Verify profile & version number
    - http://10.42.81.17:7005/vms/services/otp/build-info
    - http://10.42.81.17:7006/vms/services/build-info
- Verify properties if needed
    - http://ip:7005/vms/services/otp/env
    - http://ip:7006/vms/services/env
- Stop micro services
    - `systemctl stop vms-otp.service`
    - `systemctl stop vms-event-processing.service`