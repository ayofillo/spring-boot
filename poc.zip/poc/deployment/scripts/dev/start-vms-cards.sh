#!/bin/sh
nohup java -jar /opt/vms-ms/apps/vms-cards.jar \
--ENCRYPT_KEY=rayadanda06bhirkateri \
--PORT=7023 \
--PROFILE=dev \
--CONFIG_SVC_URL=http://10.42.16.191:8888 \
--DISCOVERY_SVC_URL=http://10.42.16.191:8761/eureka/ \
--LOG_PATH=/opt/vms-ms/logs \
& echo $! > /opt/vms-ms/scripts/.vms-cards-pid.file &
