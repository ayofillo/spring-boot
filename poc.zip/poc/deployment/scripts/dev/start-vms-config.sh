#!/bin/sh
nohup java -jar /opt/vms-ms/apps/vms-config.jar \
--ENCRYPT_KEY=rayadanda06bhirkateri \
--PORT=8888 \
--PROFILE=native \
--CONFIG_REPO_DIR=/opt/vms-ms/vms-config-data \
--LOG_PATH=/opt/vms-ms/logs \
& echo $! > /opt/vms-ms/scripts/.vms-config-pid.file &