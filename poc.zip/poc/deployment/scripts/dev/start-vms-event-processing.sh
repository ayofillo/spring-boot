#!/bin/sh
nohup java -jar /opt/vms-ms/apps/vms-event-processing.jar \
--PORT=7006 \
--PROFILE=dev \
--CONFIG_DIR=/opt/vms-ms/config \
--LOG_PATH=/opt/vms-ms/logs \
& echo $! > /opt/vms-ms/scripts/.vms-event-processing-pid.file &
