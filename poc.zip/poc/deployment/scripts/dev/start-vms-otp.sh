#!/bin/sh
nohup java -jar /opt/vms-ms/apps/vms-otp.jar \
--ENCRYPT_KEY=rayadanda06bhirkateri \
--PORT=7005 \
--PROFILE=dev \
--CONFIG_SVC_URL=http://10.42.16.191:8888 \
--DISCOVERY_SVC_URL=http://10.42.16.191:8761/eureka/ \
--LOG_PATH=/opt/vms-ms/logs \
& echo $! > /opt/vms-ms/scripts/.vms-otp-pid.file &
