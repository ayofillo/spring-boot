#!/bin/bash
kill $(cat /opt/vms-ms/scripts/.vms-batch-jobs-ui-pid.file)
