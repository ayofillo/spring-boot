#!/bin/bash
kill $(cat /opt/vms-ms/scripts/.vms-cards-pid.file)
