#!/bin/bash
kill $(cat /opt/vms-ms/scripts/.vms-ccpa-pid.file)
