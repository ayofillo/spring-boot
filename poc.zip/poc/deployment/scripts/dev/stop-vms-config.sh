#!/bin/bash
kill $(cat /opt/vms-ms/scripts/.vms-config-pid.file)
