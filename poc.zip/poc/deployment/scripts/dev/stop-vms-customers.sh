#!/bin/bash
kill $(cat /opt/vms-ms/scripts/.vms-customers-pid.file)
