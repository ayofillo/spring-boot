#!/bin/bash
kill $(cat /opt/vms-ms/scripts/.vms-event-processing-pid.file)
