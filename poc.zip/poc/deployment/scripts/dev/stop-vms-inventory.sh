#!/bin/bash
kill $(cat /opt/vms-ms/scripts/.vms-inventory-pid.file)
