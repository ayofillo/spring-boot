kill $(cat /opt/vms-ms/scripts/.vms-tms-pid.file)
