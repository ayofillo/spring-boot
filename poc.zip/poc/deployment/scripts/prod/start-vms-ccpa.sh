#!/bin/sh
nohup java -jar /opt/vms-ms/apps/vms-ccpa.jar \
--ENCRYPT_KEY=rayadanda06bhirkateri \
--PORT=7013 \
--PROFILE=prod \
--CONFIG_SVC_URL=http://spvmsaps32fv:8888 \
--DISCOVERY_SVC_URL=http://spvmsaps32fv:8761/eureka/ \
--LOG_PATH=/opt/vms-ms/logs \
& echo $! > /opt/vms-ms/scripts/.vms-ccpa-pid.file &