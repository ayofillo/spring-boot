#!/bin/sh
nohup java -jar /opt/vms-ms/apps/vms-event-processing.jar \
--ENCRYPT_KEY=rayadanda06bhirkateri \
--PORT=7006 \
--PROFILE=prod \
--CONFIG_SVC_URL=http://spvmsaps31fv:8888 \
--DISCOVERY_SVC_URL=http://spvmsaps31fv:8761/eureka/ \
--LOG_PATH=/opt/vms-ms/logs \
& echo $! > /opt/vms-ms/scripts/.vms-event-processing-pid.file &
