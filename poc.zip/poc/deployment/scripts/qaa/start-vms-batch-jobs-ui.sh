#!/bin/sh
nohup java -jar /opt/vms-ms/apps/vms-batch-jobs-ui.jar \
--PORT=7011 \
--PROFILE=qaa \
--CONFIG_DIR=/opt/vms-ms/config \
--LOG_PATH=/opt/vms-ms/logs \
& echo $! > /opt/vms-ms/scripts/.vms-batch-jobs-ui-pid.file &
