#!/bin/sh
nohup java -jar /opt/vms-ms/apps/vms-gateway.jar \
--PORT=7777 \
--PROFILE=qaa \
--CONFIG_SVC_URL=http://10.42.82.110:8888 \
--DISCOVERY_SVC_URL=http://10.42.82.110:8761/eureka/ \
--LOG_PATH=/opt/vms-ms/logs \
& echo $! > /opt/vms-ms/scripts/.vms-gateway-pid.file &