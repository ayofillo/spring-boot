#!/bin/sh
nohup java -jar /opt/vms-ms/apps/vms-discovery.jar \
--PORT=8761 \
--PROFILE=qab \
& echo $! > /opt/vms-ms/scripts/.vms-discovery-pid.file &
