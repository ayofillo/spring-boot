#!/bin/sh
nohup java -jar /opt/vms-ms/apps/vms-event-processing.jar \
--ENCRYPT_KEY=rayadanda06bhirkateri \
--PORT=7006 \
--PROFILE=qab \
--CONFIG_SVC_URL=http://10.42.81.17:8888 \
--DISCOVERY_SVC_URL=http://10.42.81.17:8761/eureka/ \
--LOG_PATH=/opt/vms-ms/logs \
& echo $! > /opt/vms-ms/scripts/.vms-event-processing-pid.file &
