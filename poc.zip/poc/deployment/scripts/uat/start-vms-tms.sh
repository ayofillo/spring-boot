#!/bin/sh
nohup java -jar /opt/vms-ms/apps/vms-tms.jar \
--APP_NAME=vms-tms\
--PORT=7130 \
--PROFILE=uat \
--CONFIG_DIR=/opt/vms-ms/config \
--LOG_PATH=/opt/vms-ms/logs \
& echo $! > /opt/vms-ms/scripts/.vms-tms-pid.file &
