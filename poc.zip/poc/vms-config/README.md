# VMS Config Server

## Config Properties Encryption
### Setup
- Setup encryption key in `/etc/profile` file
```
ENCRYPT_KEY=rayadanda@06bhirkateri
```

### Encrypt

### Docker

The vms-config can be built and run on docker container and here is the instruction to build and run the image:
- cd into vms-config project workspace: `cd vms-config`
- Run docker build command: `docker build -t vms-config`

In order to run the docker image execute the following commands for local run, for example:
- The service can be started by using docker-compose command: `docker-compose up`. Make sure to edit the file with environment specific settings.
- Or else it could be started using the command, for example 
- `docker run -e "SPRING_PROFILES_ACTIVE=local" -p 8888:8888 -v C:\Users\rdevkota\workarea\vms-config-data:/vms-config-data -t vms-config`

Note: Replace the path `C:\Users\rdevkota\workarea\vms-config-data` to point to `vms-config-data` folder where you have cloned the project.