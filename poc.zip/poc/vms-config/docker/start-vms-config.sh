#!/bin/sh
java -jar /vms-config.jar --ENCRYPT_KEY=rayadanda06bhirkateri --PROFILE=native --CONFIG_REPO_DIR=/vms-config-data --LOG_PATH=/logs