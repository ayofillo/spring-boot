package com.incomm.vms.core;

import brave.propagation.ExtraFieldPropagation;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Optional;
import java.util.UUID;

import static com.incomm.vms.core.CoreConstants.*;

@Component
@Slf4j
@Order(1)
public class ContextInitFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        long s = System.currentTimeMillis();
        try {
            String url = request.getRequestURL() + (request.getQueryString() != null ? "?" + request.getQueryString() : "");
            MDC.put(CoreConstants.REQUEST_URL, url);

            String cid = getCorrelationId(request);
            MDC.put(CORRELATION_ID, cid);
            MDC.put(DELIVERY_CHANNEL, request.getHeader(HTTP_HEADER_CHANNEL));
            MDC.put(PARTNER_ID, request.getHeader(HTTP_HEADER_PARTNER_ID));

            String bCorrelationId = Optional.ofNullable(ExtraFieldPropagation.get(HTTP_HEADER_CORRELATION_ID))
                                            .orElse(cid);
            ExtraFieldPropagation.set(HTTP_HEADER_CORRELATION_ID, bCorrelationId);

            filterChain.doFilter(request, response);
        } finally {
            long e = System.currentTimeMillis();
            log.info("Request trip time {} milliseconds", (e - s));

            // last thing to do
            MDC.clear();
        }
    }

    private String getCorrelationId(HttpServletRequest request) {
        String cid = request.getHeader(HTTP_HEADER_CORRELATION_ID);
        if (cid != null && !cid.isEmpty()) {
            return cid;
        }

        cid = MDCUtils.getCorrelationId();
        if (cid != null && !cid.isEmpty()) {
            return cid;
        }

        return UUID.randomUUID().toString();
    }
}