package com.incomm.vms.core;

import brave.Tracing;
import brave.propagation.B3Propagation;
import brave.propagation.ExtraFieldPropagation;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.ThreadPoolExecutor;

@Configuration
@EnableEurekaClient
@PropertySource("classpath:application.properties")
@RefreshScope
@Data
@Slf4j
public class CoreConfig implements InitializingBean {
    @Value("${core.thread.pool.core-size:25}")
    private int threadPoolCoreSize;

    @Value("${core.thread.pool.queue-capacity:50}")
    private int threadPoolQueueCapacity;

    @Value("${core.thread.pool.max-size:50}")
    private int threadPoolMaxSize;

    @Value("${core.thread.name-prefix:VMS_THREAD_}")
    private String threadNamePrefix;

    @Value("${core.req-resp.logging.enable:false}")
    private boolean enableReqRespLog;

    @Value("${core.exception-handler:CoreExceptionHandler}")
    private String exceptionHandler;

    @Bean
    @Qualifier("coreAsyncExecutor")
    public TaskExecutor coreAsyncExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setTaskDecorator(new MdcTaskDecorator());
        executor.setThreadNamePrefix(threadNamePrefix);
        executor.setCorePoolSize(threadPoolCoreSize);
        executor.setQueueCapacity(threadPoolQueueCapacity);
        executor.setMaxPoolSize(threadPoolMaxSize);
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        executor.setWaitForTasksToCompleteOnShutdown(true);
        executor.initialize();
        return executor;
    }

    @Bean
    public Tracing.Builder tracerBuilder() {
        // when you initialize the builder, define the extra field you want to propagate
        return Tracing.newBuilder().propagationFactory(
                ExtraFieldPropagation.newFactory(B3Propagation.FACTORY, CoreConstants.HTTP_HEADER_CORRELATION_ID)
        );
    }

    @Bean
    public RequestResponseConsumer fileLoggerConsumer(ObjectMapper objectMapper) {
        return new CoreRequestResponseLogger(objectMapper);
    }

    @Bean
    public VmsErrorCodesParser vmsErrorCodesParser(VmsErrorCodesRepo errorCodesRepo) {
        return new VmsErrorCodesParser(errorCodesRepo);
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        log.info("VMS core configurations :: " + this.toString());
    }
}
