package com.incomm.vms.core;

public final class CoreConstants {
    public static final String CORRELATION_ID = "correlationId";
    public static final String DELIVERY_CHANNEL = "channel";
    public static final String PARTNER_ID = "partnerId";
    public static final String REQUEST_URL = "url";
    public static final String HTTP_HEADER_CORRELATION_ID = "x-incfs-correlationid";
    @Deprecated
    public static final String HTTP_HEADER_DELIVERY_CHANNEL = "x-incfs-deliveryChannel";
    public static final String HTTP_HEADER_CHANNEL = "x-incfs-channel";
    public static final String HTTP_HEADER_PARTNER_ID = "x-incfs-partnerId";
}
