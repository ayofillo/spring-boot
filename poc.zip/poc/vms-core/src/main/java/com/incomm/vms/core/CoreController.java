package com.incomm.vms.core;

import org.springframework.http.ResponseEntity;

import java.time.LocalDateTime;
import java.util.function.Supplier;

public abstract class CoreController {

    /**
     * @param responseSupplier
     * @param <T>
     * @return
     * @deprecated use {@link CoreController#executeService(Supplier)}
     */
    public <T> ResponseEntity<Response<T>> invokeService(Supplier<T> responseSupplier) {
        T data = responseSupplier.get();

        Response<T> resp = new Response<>();
        resp.setData(data);
        resp.setStatus(Status.builder()
                             .code("00")
                             .message("SUCCESS")
                             .correlationId(MDCUtils.getCorrelationId())
                             .timestamp(LocalDateTime.now())
                             .build());

        return ResponseEntity.ok(resp);
    }

    public <T> ResponseEntity<VmsResponse<T>> executeService(Supplier<T> responseSupplier) {
        T data = responseSupplier.get();

        VmsResponse<T> resp = new VmsResponse<>();
        resp.setResponseBody(data);
        resp.setResponseCode("00");
        resp.setResponseMessage("SUCCESS");
        resp.setCorrelationId(MDCUtils.getCorrelationId());

        return ResponseEntity.ok(resp);
    }
}
