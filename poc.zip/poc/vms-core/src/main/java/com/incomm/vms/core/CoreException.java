package com.incomm.vms.core;

import lombok.Getter;

@Getter
public abstract class CoreException extends RuntimeException {
    private final String code;

    public CoreException(String code, String message) {
        this(code, message, null);
    }

    public CoreException(String code, String message, Throwable throwable) {
        super(message, throwable);
        this.code = code;
    }
}
