package com.incomm.vms.core;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDateTime;
import java.util.stream.Collectors;

import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;


@RestControllerAdvice
@ConditionalOnMissingBean(annotation = RestControllerAdvice.class)
@ConditionalOnProperty(value = {"core.exception-handler"}, havingValue = "CoreExceptionHandler", matchIfMissing = true)
@Slf4j
@Deprecated
class CoreExceptionHandler extends ResponseEntityExceptionHandler implements InitializingBean {

    /**
     * Triggered when {@link CoreException} occurs.
     *
     * @param ex
     * @param request
     * @return
     */
    @ExceptionHandler(CoreException.class)
    public final ResponseEntity<Object> handleExceptions(CoreException ex, WebRequest request) {
        log.error(ex.getMessage(), ex);

        Response<Object> body = new Response<>();
        body.setStatus(Status.builder()
                             .code(StringUtils.isBlank(ex.getCode()) ? Integer.toString(INTERNAL_SERVER_ERROR.value()) : ex.getCode())
                             .message(ex.getMessage())
                             .correlationId(MDCUtils.getCorrelationId())
                             .timestamp(LocalDateTime.now())
                             .build());

        return ResponseEntity.ok(body);
    }

    /**
     * Default exception handler if specific exception handler is not defined.
     *
     * @param ex
     * @param request
     * @return
     */
    @ExceptionHandler(Exception.class)
    public final ResponseEntity<Object> handleExceptions(Exception ex, WebRequest request) {
        log.error(ex.getMessage(), ex);

        Response<Object> body = new Response<>();
        body.setStatus(Status.builder()
                             .code(Integer.toString(INTERNAL_SERVER_ERROR.value()))
                             .message(ex.getMessage())
                             .correlationId(MDCUtils.getCorrelationId())
                             .timestamp(LocalDateTime.now())
                             .build());

        return ResponseEntity.ok(body);
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        log.error(ex.getMessage(), ex);

        String message = ex.getBindingResult().getFieldErrors()
                           .stream()
                           .map(fe -> fe.getField() + " : " + fe.getDefaultMessage())
                           .collect(Collectors.joining(", "));

        Response<Object> body = new Response<>();
        body.setStatus(Status.builder()
                             .code(Integer.toString(status.value()))
                             .message(message)
                             .correlationId(MDCUtils.getCorrelationId())
                             .timestamp(LocalDateTime.now())
                             .build());

        return ResponseEntity.ok(body);
    }

    /**
     * Triggered when POST request payload is missing.
     *
     * @param ex
     * @param headers
     * @param status
     * @param request
     * @return
     */
    protected ResponseEntity<Object> handleHttpMessageNotReadable(HttpMessageNotReadableException ex,
                                                                  HttpHeaders headers, HttpStatus status, WebRequest request) {
        log.error(ex.getMessage(), ex);

        Response<Object> body = new Response<>();
        body.setStatus(Status.builder()
                             .code(Integer.toString(status.value()))
                             .message(ex.getMessage())
                             .correlationId(MDCUtils.getCorrelationId())
                             .timestamp(LocalDateTime.now())
                             .build());

        return ResponseEntity.ok(body);
    }

    @Override
    protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(HttpRequestMethodNotSupportedException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        log.error(ex.getMessage(), ex);
        return buildResponseEntity(status);
    }

    private ResponseEntity<Object> buildResponseEntity(HttpStatus status) {
        Response<Object> body = new Response<>();
        body.setStatus(Status.builder()
                             .code(Integer.toString(status.value()))
                             .message(status.name())
                             .correlationId(MDCUtils.getCorrelationId())
                             .timestamp(LocalDateTime.now())
                             .build());
        return new ResponseEntity(body, status);
    }

    @Autowired
    private CoreConfig coreConfig;

    @Override
    public void afterPropertiesSet() throws Exception {
        log.info("VMS global exception handler :: core.exception-handler : {} => {}", coreConfig.getExceptionHandler(), this.getClass().getName());
    }
}
