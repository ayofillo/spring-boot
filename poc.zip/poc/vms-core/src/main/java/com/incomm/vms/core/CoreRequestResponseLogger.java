package com.incomm.vms.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

import static java.util.Arrays.asList;

@Slf4j
public class CoreRequestResponseLogger implements RequestResponseConsumer {
    private final ObjectMapper objectMapper;

    public CoreRequestResponseLogger(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @SneakyThrows
    @Override
    public void accept(ReqRespLog reqRespLog) {
        log.info(objectMapper.writeValueAsString(reqRespLog));
    }

    @Override
    public UrlPattern getUrlPattern() {
        return new UrlPatternExclude(asList("**/swagger*", "**/actuator/**", "**/logs", "**/logs/**"));
    }
}


