package com.incomm.vms.core;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.HashMap;
import java.util.Map;

import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ErrorInfo {
    private String code;
    private String message;

    public static ErrorInfo buildFromException(CoreException ex, VmsErrorCodesRepo errorCodesRepo) {
        String code = ex.getCode();
        boolean codeAvailable = code != null && !code.isEmpty();
        ErrorInfo errorInfo = ErrorInfo.builder()
                                       .code(codeAvailable ? code : String.valueOf(INTERNAL_SERVER_ERROR.value()))
                                       .message(ex.getMessage())
                                       .build();
        if (codeAvailable && code.contains(":") && code.split(":").length == 2) {
            String[] split = code.split(":");
            String featureName = split[0];
            String errorName = split[1];

            ErrorInfo finalErrorInfo = errorInfo;
            errorInfo = errorCodesRepo.getErrors()
                                      .getOrDefault(featureName, new HashMap<String, ErrorInfo>() {{
                                          put(errorName, finalErrorInfo);
                                      }})
                                      .getOrDefault(errorName, errorInfo);

            // not configured in YML or null or empty
            if (errorInfo.getMessage() == null || errorInfo.getMessage().isEmpty()) {
                errorInfo.setMessage(ex.getMessage());
            }
            if (errorInfo.getCode() == null || errorInfo.getCode().isEmpty()) {
                errorInfo.setCode(codeAvailable ? code : String.valueOf(INTERNAL_SERVER_ERROR.value()));
            }
        }

        return errorInfo;
    }

    public static void main(String[] args) {
        CoreException coreException = new CoreException("instore-replacement:INVALID_CARD", "Invalid card exception") {
        };

        HashMap<String, ErrorInfo> errorMap = new HashMap<String, ErrorInfo>() {{
            put("INVALID_CARD", ErrorInfo.builder().code("").message("").build());
        }};

        HashMap<String, Map<String, ErrorInfo>> featureErrors = new HashMap<String, Map<String, ErrorInfo>>() {{
            put("instore-replacement", errorMap);
        }};

        VmsErrorCodesRepo errorCodesRepo = new VmsErrorCodesRepo();
        errorCodesRepo.setErrors(featureErrors);

        ErrorInfo errorInfo = ErrorInfo.buildFromException(coreException, errorCodesRepo);

        System.out.println(errorInfo);
    }
}
