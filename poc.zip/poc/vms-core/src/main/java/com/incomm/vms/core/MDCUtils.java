package com.incomm.vms.core;

import org.slf4j.MDC;

import java.util.Optional;

public class MDCUtils {
    public static String getCorrelationId() {
        return Optional.ofNullable(MDC.get(CoreConstants.CORRELATION_ID))
                       .orElseGet(() -> MDC.get("X-B3-TraceId"));
    }
}
