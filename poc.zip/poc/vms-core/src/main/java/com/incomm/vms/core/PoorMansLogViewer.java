package com.incomm.vms.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import static java.util.Comparator.comparing;
import static java.util.stream.Collectors.toList;

@RestController
@ConditionalOnProperty(value = {"logging.file.name", "logging.file.path"})
public class PoorMansLogViewer {

    @Value("${logging.file.name}")
    private String logFile;

    @Value("${logging.file.path}")
    private String logPath;

    private final ObjectMapper objectMapper;

    public PoorMansLogViewer(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    @GetMapping("/logs")
    public Object logs(@RequestParam Map<String, String> queryParams) {
        return readLogs(queryParams);
    }

    private List<Map<String, String>> readLogs(Map<String, String> queryParams) {
        File file = new File(logPath + "/" + logFile + ".json");
        try {
            List<Map<String, String>> logs = Files.lines(file.toPath())
                                                  .map(this::intoMap)
                                                  .filter(logMap -> satisfiesQueryParams(logMap, queryParams))
                                                  .collect(toList());
            logs.sort(Collections.reverseOrder(comparing(m -> m.get("@timestamp"))));
            return logs;
        } catch (Exception e) {
            return Collections.emptyList();
        }
    }

    private boolean satisfiesQueryParams(Map<String, String> logMap, Map<String, String> queryParams) {
        boolean entryNotAvailableInLogMap = queryParams.entrySet()
                                                       .stream()
                                                       .filter(e -> entryNotAvailableInLogMap(logMap, e))
                                                       .findAny()
                                                       .isPresent();

        return !entryNotAvailableInLogMap;
    }

    private boolean entryNotAvailableInLogMap(Map<String, String> logMap, Map.Entry<String, String> e) {
        return !(logMap.keySet().contains(e.getKey()) && logMap.get(e.getKey()).contains(e.getValue()));
    }

    private Map<String, String> intoMap(String json) {
        try {
            return objectMapper.readValue(json, Map.class);
        } catch (IOException e) {
            throw new RuntimeException();
        }
    }
}
