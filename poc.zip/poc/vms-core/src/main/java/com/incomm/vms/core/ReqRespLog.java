package com.incomm.vms.core;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ReqRespLog {
    private String method;
    private String path;
    private String headers;
    private Object request;
    private Object response;
}
