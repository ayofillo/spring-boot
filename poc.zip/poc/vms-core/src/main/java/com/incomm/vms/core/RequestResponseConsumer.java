package com.incomm.vms.core;

import org.springframework.util.AntPathMatcher;

import java.util.function.Consumer;

public interface RequestResponseConsumer extends Consumer<ReqRespLog> {
    UrlPattern getUrlPattern();

    default boolean isApplicableToPath(String path) {
        if (getUrlPattern() instanceof UrlPatternExclude) {
            boolean exclude = getUrlPattern().getPattern()
                                             .stream()
                                             .anyMatch(pattern -> new AntPathMatcher().match(pattern, path));
            return !exclude;
        } else {
            return getUrlPattern().getPattern()
                                  .stream()
                                  .anyMatch(pattern -> new AntPathMatcher().match(pattern, path));
        }
    }
}
