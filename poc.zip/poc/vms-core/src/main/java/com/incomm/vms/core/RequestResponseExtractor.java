package com.incomm.vms.core;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import static java.util.Collections.emptyList;

@Component
@Slf4j
@Order(99)
public class RequestResponseExtractor extends OncePerRequestFilter {
    private final CoreConfig coreConfig;
    private final List<RequestResponseConsumer> consumers;
    private final ObjectMapper objectMapper;

    public RequestResponseExtractor(CoreConfig coreConfig, List<RequestResponseConsumer> consumers, ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
        this.coreConfig = coreConfig;
        this.consumers = consumers != null ? consumers : emptyList();
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        if (isAsyncDispatch(request)) {
            filterChain.doFilter(request, response);
        } else {
            doFilterWrapped(wrapRequest(request), wrapResponse(response), filterChain);
        }
    }

    protected void doFilterWrapped(ContentCachingRequestWrapper request, ContentCachingResponseWrapper response, FilterChain filterChain) throws ServletException, IOException {
        try {
            filterChain.doFilter(request, response);
        } finally {
            if (coreConfig.isEnableReqRespLog()) {
                extractRequestResponse(request, response).ifPresent(this::supplyRequestResponseToConsumers);
            }
            response.copyBodyToResponse();
        }
    }

    private void supplyRequestResponseToConsumers(ReqRespLog reqRespLog) {
        try {
            consumers.stream()
                     .filter(c -> c.isApplicableToPath(reqRespLog.getPath()))
                     .forEach(c -> {
                         try {
                             c.accept(reqRespLog);
                         } catch (Exception ex) {
                             // ignore
                             log.warn(ex.getMessage());
                         }
                     });
        } catch (Exception ex) {
            // ignore
            log.warn(ex.getMessage(), ex);
        }
    }

    private Optional<ReqRespLog> extractRequestResponse(ContentCachingRequestWrapper request, ContentCachingResponseWrapper response) {
        try {
            // headers
            String headers = Collections.list(request.getHeaderNames())
                                        .stream()
                                        .map(h -> h + " = " + request.getHeader(h))
                                        .collect(Collectors.joining(","));

            byte[] reqBytes = request.getContentAsByteArray();
            String reqBody = byteArrayIntoString(reqBytes, request.getCharacterEncoding());

            byte[] respBytes = response.getContentAsByteArray();
            String respBody = byteArrayIntoString(respBytes, response.getCharacterEncoding());

            Object reqObj = reqBody.isEmpty() ? "{}" : objectMapper.readValue(reqBody, Object.class);
            Object respObj = respBody.isEmpty() ? "{}" : objectMapper.readValue(respBody, Object.class);

            objectMapper.enable(SerializationFeature.INDENT_OUTPUT);
            return Optional.of(ReqRespLog.builder()
                                         .method(request.getMethod())
                                         .path(request.getRequestURL().toString())
                                         .headers(headers)
                                         .request(reqObj)
                                         .response(respObj)
                                         .build());
        } catch (Exception ex) {
            // ignore
            log.warn("Error while extracting request & response. " + ex.getMessage());
            return Optional.empty();
        }
    }

    private static ContentCachingRequestWrapper wrapRequest(HttpServletRequest request) {
        if (request instanceof ContentCachingRequestWrapper) {
            return (ContentCachingRequestWrapper) request;
        } else {
            return new ContentCachingRequestWrapper(request);
        }
    }

    private static ContentCachingResponseWrapper wrapResponse(HttpServletResponse response) {
        if (response instanceof ContentCachingResponseWrapper) {
            return (ContentCachingResponseWrapper) response;
        } else {
            return new ContentCachingResponseWrapper(response);
        }
    }

    private String byteArrayIntoString(byte[] content, String contentEncoding) {
        try {
            return new String(content, contentEncoding);
        } catch (UnsupportedEncodingException e) {
            log.error(e.getMessage(), e);
            return "";
        }
    }
}
