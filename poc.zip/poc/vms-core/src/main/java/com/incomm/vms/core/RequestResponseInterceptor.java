package com.incomm.vms.core;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.util.StreamUtils;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

@Slf4j
public class RequestResponseInterceptor implements ClientHttpRequestInterceptor {
    private BiConsumer<HttpRequest, byte[]> requestConsumer;
    private Consumer<ClientHttpResponse> responseConsumer;

    public RequestResponseInterceptor() {
        this.requestConsumer = this::logRequest;
        this.responseConsumer = this::logResponse;
    }

    public RequestResponseInterceptor(BiConsumer<HttpRequest, byte[]> requestConsumer, Consumer<ClientHttpResponse> responseConsumer) {
        this.requestConsumer = requestConsumer;
        this.responseConsumer = responseConsumer;
    }

    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException {
        requestConsumer.accept(request, body);
        long start = System.currentTimeMillis();
        ClientHttpResponse response = execution.execute(request, body);
        long end = System.currentTimeMillis();
        responseConsumer.accept(response);
        log.debug("Ext API call :: " + request.getURI() + ", total time = " + (end - start) + " millisec.");
        return response;
    }

    private void logRequest(HttpRequest request, byte[] body) {
        try {
            String msg = "";
            msg += "===========================request begin================================================\n";
            msg += "URI         : " + request.getURI() + "\n";
            msg += "Method      : " + request.getMethod() + "\n";
            msg += "Headers     : " + request.getHeaders() + "\n";
            msg += "Request body: " + new String(body, "UTF-8") + "\n";
            msg += "==========================request end================================================\n";
            log.debug(msg);
        } catch (IOException ex) {
            // ignore
            log.error("Error while trying to log request.", ex);
        }
    }

    private void logResponse(ClientHttpResponse response) {
        try {
            String msg = "";
            msg += "============================response begin==========================================\n";
            msg += "Status code  : " + response.getStatusCode() + "\n";
            msg += "Status text  : " + response.getStatusText() + "\n";
            msg += "Headers      : " + response.getHeaders() + "\n";
            msg += "Response body: " + StreamUtils.copyToString(response.getBody(), Charset.defaultCharset()) + "\n";
            msg += "=======================response end=================================================\n";
            log.debug(msg);
        } catch (IOException ex) {
            // ignore
            log.error("Error while trying to log response.", ex);
        }
    }
}