package com.incomm.vms.core;

import lombok.Data;

@Deprecated
@Data
public class Response<T> {
    private Status status;
    private T data;
}
