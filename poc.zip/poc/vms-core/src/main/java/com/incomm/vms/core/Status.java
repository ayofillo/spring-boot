package com.incomm.vms.core;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Deprecated
@Builder
@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Status {
    private String code;
    private String message;
    private String correlationId;
    private LocalDateTime timestamp;
}
