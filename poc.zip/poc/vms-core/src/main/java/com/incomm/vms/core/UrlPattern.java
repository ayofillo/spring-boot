package com.incomm.vms.core;

import java.util.List;

public interface UrlPattern {
    List<String> getPattern();
}
