package com.incomm.vms.core;

import lombok.Value;

import java.util.List;

@Value
public class UrlPatternExclude implements UrlPattern {
    List<String> pattern;

    @Override
    public List<String> getPattern() {
        return this.pattern;
    }
}
