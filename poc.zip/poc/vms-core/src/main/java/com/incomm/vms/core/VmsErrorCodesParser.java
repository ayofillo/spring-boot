package com.incomm.vms.core;

public class VmsErrorCodesParser {
    private final VmsErrorCodesRepo codesRepo;

    public VmsErrorCodesParser(VmsErrorCodesRepo codesRepo) {
        this.codesRepo = codesRepo;
    }

    public ErrorInfo buildFromExcepion(CoreException ex) {
        return ErrorInfo.buildFromException(ex, codesRepo);
    }
}
