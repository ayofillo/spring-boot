package com.incomm.vms.core;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

import static java.util.Collections.emptyMap;

@Data
@Slf4j
@RefreshScope
@Configuration
@ConfigurationProperties(prefix = "vms")
public class VmsErrorCodesRepo implements InitializingBean {
    // key = feature name e.g. instore-replacement
    // value = Map<error name => ErrorInfo> e.g. INVALID_CARD => ErrorInfo
    // e.g. <instore-replacement => <INVALID_CARD => ErrorInfo>>
    private Map<String, Map<String, ErrorInfo>> errors = emptyMap();

    @Override
    public void afterPropertiesSet() {
        log.info("VMS error codes repo :: " + errors);
    }

    public Map<String, Map<String, ErrorInfo>> getErrors() {
        return cloneErrorInfo();
    }

    private Map<String, Map<String, ErrorInfo>> cloneErrorInfo() {
        try {
            ObjectMapper om = new ObjectMapper();
            String json = om.writeValueAsString(errors);
            HashMap<String, Map<String, ErrorInfo>> data = om.readValue(json, new TypeReference<HashMap<String, Map<String, ErrorInfo>>>() {
            });
            return data;
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e.getMessage(), e);
        }
    }
}