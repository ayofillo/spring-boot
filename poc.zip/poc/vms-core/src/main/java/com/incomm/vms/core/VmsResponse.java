package com.incomm.vms.core;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Data;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
public class VmsResponse<T> {
    private String responseCode;
    private String responseMessage;
    private String correlationId;
    private T responseBody;
}
