package com.incomm.vms.core;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ErrorInfoTest {

    @Test
    void buildFromException_all_good_scenario() {
        CoreException excpThrownByService = new CoreException("instore-replacement:INVALID_CARD", "Invalid card exception") {
        };

        // simulate error config repo
        HashMap<String, ErrorInfo> errorMap = new HashMap<>();
        errorMap.put("INVALID_CARD", ErrorInfo.builder().code("INSR-02").message("Invalid card message").build());
        HashMap<String, Map<String, ErrorInfo>> featureErrors = new HashMap<>();
        featureErrors.put("instore-replacement", errorMap);
        VmsErrorCodesRepo errorCodesRepo = new VmsErrorCodesRepo();
        errorCodesRepo.setErrors(featureErrors);

        ErrorInfo errorInfo = ErrorInfo.buildFromException(excpThrownByService, errorCodesRepo);
        assertEquals(ErrorInfo.builder().code("INSR-02").message("Invalid card message").build(),
                errorInfo);
    }

    @Test
    void buildFromException_message_config_missing() {
        CoreException excpThrownByService = new CoreException("instore-replacement:INVALID_CARD", "Invalid card exception") {
        };

        // simulate error config repo
        HashMap<String, ErrorInfo> errorMap = new HashMap<>();
        errorMap.put("INVALID_CARD", ErrorInfo.builder().code("INSR-02").build());
        HashMap<String, Map<String, ErrorInfo>> featureErrors = new HashMap<>();
        featureErrors.put("instore-replacement", errorMap);
        VmsErrorCodesRepo errorCodesRepo = new VmsErrorCodesRepo();
        errorCodesRepo.setErrors(featureErrors);

        ErrorInfo errorInfo = ErrorInfo.buildFromException(excpThrownByService, errorCodesRepo);
        assertEquals(ErrorInfo.builder().code("INSR-02").message("Invalid card exception").build(),
                errorInfo);
    }

    @Test
    void buildFromException_empty_message_config() {
        CoreException excpThrownByService = new CoreException("instore-replacement:INVALID_CARD", "Invalid card exception") {
        };

        // simulate error config repo
        HashMap<String, ErrorInfo> errorMap = new HashMap<>();
        errorMap.put("INVALID_CARD", ErrorInfo.builder().code("INSR-02").message("").build());
        HashMap<String, Map<String, ErrorInfo>> featureErrors = new HashMap<>();
        featureErrors.put("instore-replacement", errorMap);
        VmsErrorCodesRepo errorCodesRepo = new VmsErrorCodesRepo();
        errorCodesRepo.setErrors(featureErrors);

        ErrorInfo errorInfo = ErrorInfo.buildFromException(excpThrownByService, errorCodesRepo);
        assertEquals(ErrorInfo.builder().code("INSR-02").message("Invalid card exception").build(),
                errorInfo);
    }

    @Test
    void buildFromException_code_config_missing() {
        CoreException excpThrownByService = new CoreException("instore-replacement:INVALID_CARD", "Invalid card exception") {
        };

        // simulate error config repo
        HashMap<String, ErrorInfo> errorMap = new HashMap<>();
        errorMap.put("INVALID_CARD", ErrorInfo.builder().message("").build());
        HashMap<String, Map<String, ErrorInfo>> featureErrors = new HashMap<>();
        featureErrors.put("instore-replacement", errorMap);
        VmsErrorCodesRepo errorCodesRepo = new VmsErrorCodesRepo();
        errorCodesRepo.setErrors(featureErrors);

        ErrorInfo errorInfo = ErrorInfo.buildFromException(excpThrownByService, errorCodesRepo);
        assertEquals(ErrorInfo.builder().code("instore-replacement:INVALID_CARD").message("Invalid card exception").build(),
                errorInfo);
    }

    @Test
    void buildFromException_empty_code_config() {
        CoreException excpThrownByService = new CoreException("instore-replacement:INVALID_CARD", "Invalid card exception") {
        };

        // simulate error config repo
        HashMap<String, ErrorInfo> errorMap = new HashMap<>();
        errorMap.put("INVALID_CARD", ErrorInfo.builder().code("").build());
        HashMap<String, Map<String, ErrorInfo>> featureErrors = new HashMap<>();
        featureErrors.put("instore-replacement", errorMap);
        VmsErrorCodesRepo errorCodesRepo = new VmsErrorCodesRepo();
        errorCodesRepo.setErrors(featureErrors);

        ErrorInfo errorInfo = ErrorInfo.buildFromException(excpThrownByService, errorCodesRepo);
        assertEquals(ErrorInfo.builder().code("instore-replacement:INVALID_CARD").message("Invalid card exception").build(),
                errorInfo);
    }

    @Test
    void buildFromException_exception_has_null_code() {
        CoreException excpThrownByService = new CoreException(null, "Invalid card exception") {
        };

        // simulate error config repo
        // config doesn't matter

        ErrorInfo errorInfo = ErrorInfo.buildFromException(excpThrownByService, null);
        assertEquals(ErrorInfo.builder().code("500").message("Invalid card exception").build(),
                errorInfo);
    }

//    @ParameterizedTest
//    @ValueSource(strings = {"instore-replacementINVALID_CARD", ":INVALID_CARD", "INVALID_CARD:"})
//    void buildFromException_invalid_code_pattern(String excpCode) {
//        CoreException excpThrownByService = new CoreException(excpCode, "Invalid card exception") {
//        };
//
//        // simulate error config repo
//        // doesn't matter
//
//        ErrorInfo errorInfo = ErrorInfo.buildFromException(excpThrownByService, null);
//        assertEquals(ErrorInfo.builder().code(excpCode).message("Invalid card exception").build(),
//                errorInfo);
//    }
}