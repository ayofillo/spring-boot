package com.incomm.vms.tms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jdbc.repository.config.EnableJdbcRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * @author afilegbe
 */
@EnableTransactionManagement
@EnableJdbcRepositories
@SpringBootApplication
@ComponentScan("com.incomm.vms")
public class VMSTMSApplication {
    public static void main(String[] args) {
        SpringApplication.run(VMSTMSApplication.class, args);
    }
}
