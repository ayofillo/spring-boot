package com.incomm.vms.tms.api;

import com.incomm.vms.core.CoreController;
import com.incomm.vms.core.VmsResponse;
import com.incomm.vms.security.SecurityUtils;
import com.incomm.vms.tms.component.TMSService;
import com.incomm.vms.tms.config.Constants;
import com.incomm.vms.tms.model.dao.TMSModel;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang.StringUtils;
import org.slf4j.MDC;
import org.springframework.context.ApplicationContext;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Strings.isNullOrEmpty;

/**
 * @author afilegbe
 */
@RestController
@Slf4j
@Api(value = "Entry point for tms broadcast")
public class TMSController extends CoreController {
    private final ApplicationContext ctx;   

    public TMSController(ApplicationContext ctx) {
        this.ctx = ctx;
    }

    @ApiOperation(value = "Decrypt TMS payload")
    @PostMapping(value = "/decrypt-message", consumes = "application/json", produces = "application/json")
    public ResponseEntity<VmsResponse<String>> decryptData(@RequestBody String payload) {
        checkArgument(!isNullOrEmpty(payload), "payload cannot be null");
        log.info("decrypting payload {}", payload);
        return executeService(() -> SecurityUtils.decrypt(payload));
    }

    @ApiOperation(value = "Push message to TMS")
    @PostMapping(value = "/publish-message", consumes = "application/json", produces = "application/json")
    public ResponseEntity<VmsResponse<String>> publishToTms(@RequestBody TMSModel request,
                                                         @RequestHeader(value = Constants.RRN_HEADER) String rrn,
                                                         @RequestHeader(value = Constants.MODE_HEADER) String mode,
                                                         @RequestHeader(value = Constants.SOURCE_HEADER) String source) {
        checkArgument(request != null, "request cannot be null");
        checkArgument(!isNullOrEmpty(request.getPayload()), "payload cannot be null");
        checkArgument(!isNullOrEmpty(rrn), "rrn cannot be null");
        checkArgument(!isNullOrEmpty(mode), String.format("%s header cannot be null", Constants.MODE_HEADER));
        checkArgument(!isNullOrEmpty(source), String.format("%s header cannot be null", Constants.SOURCE_HEADER));

        checkArgument(mode.equalsIgnoreCase(Constants.ERIF) || mode.equalsIgnoreCase(Constants.MRIF),
                "invalid value passed in " + Constants.MODE_HEADER);
        checkArgument(source.equalsIgnoreCase(Constants.VMS) || source.equalsIgnoreCase(Constants.GC)|| source.equalsIgnoreCase(Constants.CSD),
                "invalid value passed in " + Constants.SOURCE_HEADER);

        MDC.put(Constants.LOG_ID, String.format("%s-%s-%s", source, mode, rrn));

        log.info("Message received from {} with mode {} and validated...", source, mode);

        TMSService tmsService = ctx.getBean(TMSService.class);
        return executeService(() -> {
        	tmsService.processPushMessage(request.getPayload(), mode, source, rrn);
            return "Request submitted";
        });
    }
}
