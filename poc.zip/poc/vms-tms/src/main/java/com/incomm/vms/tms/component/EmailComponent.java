package com.incomm.vms.tms.component;

import com.incomm.vms.tms.config.Constants;
import com.incomm.vms.tms.config.Props;
import com.incomm.vms.tms.model.email.HTMLDataSource;
import com.incomm.vms.tms.model.email.OutgoingEmail;
import com.incomm.vms.tms.util.ContentIdGenerator;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.ErrorMessage;

import javax.activation.DataHandler;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

/**
 * Configurations for error processing are recorded here
 */
@MessageEndpoint
@Slf4j
public class EmailComponent {

    private final JavaMailSender emailSender;
    private final Props prop;

    @Autowired
    public EmailComponent(@Qualifier("javaMailSender") JavaMailSender emailSender, Props prop) {
        this.emailSender = emailSender;
        this.prop = prop;
    }

    @ServiceActivator(inputChannel = "emailSendingChannel")
    public void sendEmail(Message<OutgoingEmail> message) {
        MDC.put(Constants.LOG_ID, String.format("%s-%s-%s",
                message.getHeaders().get(Constants.SOURCE_HEADER),
                message.getHeaders().get(Constants.MODE_HEADER),
                message.getHeaders().get(Constants.RRN_HEADER)));

        OutgoingEmail outgoingEmail = message.getPayload();
        String text;
        try {
            String cid = ContentIdGenerator.getContentId();
            String var = "<html><body><code>" +
                    "<img style=\"width: 40px; height: 25px;\" src=\"cid:${cid}\"/><br/>" + outgoingEmail.getBody() +
                    "<code></body></html>";
            text = var.replace("${cid}", cid);

            MimeMessage msg = emailSender.createMimeMessage();
            Multipart mp = new MimeMultipart("related");

            msg.setFrom(new InternetAddress(outgoingEmail.getFromEmail(), "VMS-TMS Service"));
            for (String emailAddy : StringUtils.split(outgoingEmail.getToEmail(), ",")) {
                try {
                    msg.addRecipient(javax.mail.Message.RecipientType.TO, new InternetAddress(emailAddy));
                } catch (MessagingException e) {
                    log.error(ExceptionUtils.getStackTrace(e));
                }
            }

            msg.setSubject(outgoingEmail.getSubject());

            MimeBodyPart textPart = new MimeBodyPart();
            textPart.setDataHandler(new DataHandler(new HTMLDataSource(text)));
            textPart.setDisposition(MimeBodyPart.INLINE);

            MimeBodyPart imagePart = new MimeBodyPart();
            imagePart.attachFile(prop.getImgPath());
            imagePart.setContentID("<" + cid + ">");
            imagePart.setDisposition(MimeBodyPart.INLINE);

            mp.addBodyPart(textPart);
            mp.addBodyPart(imagePart);

            msg.setContent(mp);
            msg.saveChanges();

            try {
                emailSender.send(msg);
                log.info("Email successfully sent!!!");
            } catch (Exception e) {
                log.error("Error occurred while sending email ");
                log.error(ExceptionUtils.getStackTrace(e));
            }
        } catch (Exception e) {
            log.error("Error occurred while sending email ");
            log.error(ExceptionUtils.getStackTrace(e));
        }
    }

    @ServiceActivator(inputChannel = "exceptionChannel", outputChannel = "emailSendingChannel")
    public Object handleError2(Message<?> message) {
        return getMessageEmailDetails(message);
    }

    @ServiceActivator(inputChannel = "errorChannel", outputChannel = "emailSendingChannel")
    public Object handleError(Message<?> message) {
        return getMessageEmailDetails(message);
    }

    private Object getMessageEmailDetails(Message<?> message) {
        OutgoingEmail outgoingEmail = new OutgoingEmail();
        outgoingEmail.setToEmail(prop.getToEmail());
        outgoingEmail.setFromEmail(prop.getFromEmail());

        outgoingEmail.setSubject("TMS Service Exception - " + prop.getEnv());
        outgoingEmail.setBody(getErrorEmailContent(message));
        return outgoingEmail;
    }

    private String getErrorEmailContent(Message<?> message) {
        MDC.put(Constants.LOG_ID, String.format("%s-%s-%s",
                message.getHeaders().get(Constants.SOURCE_HEADER),
                message.getHeaders().get(Constants.MODE_HEADER),
                message.getHeaders().get(Constants.RRN_HEADER)));
        ErrorMessage errorMessage = (ErrorMessage) message;

        return "<strong>Payload:</strong> " + message.getHeaders().get(Constants.PAYLOAD) +
                "<br/> <strong>RRN:</strong> " + message.getHeaders().get(Constants.RRN_HEADER) +
                "<br/> <strong>Mode:</strong> " + message.getHeaders().get(Constants.MODE_HEADER) +
                "<br/><br/>" +
                ExceptionUtils.getStackTrace(errorMessage.getPayload());
    }

}