package com.incomm.vms.tms.component;

import com.incomm.vms.security.SecurityUtils;
import com.incomm.vms.tms.config.Constants;
import com.incomm.vms.tms.config.Props;
import com.incomm.vms.tms.dao.TMSDao;
import com.incomm.vms.tms.model.dao.TMSModel;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.exception.ExceptionUtils;
import org.slf4j.MDC;
import org.springframework.amqp.AmqpException;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.jms.JmsException;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Objects;

/**
 * @author ibayissa
 */
@Slf4j
@MessageEndpoint
public class TMSService {

    private final TmsConnector connector;
    private final Props prop;
    private final MessageChannel exceptionChannel;
    private final TMSDao dao;

    public TMSService(TmsConnector connector, Props prop,
                      @Qualifier("exceptionChannel") MessageChannel exceptionChannel, TMSDao dao) {
        this.connector = connector;
        this.prop = prop;
        this.exceptionChannel = exceptionChannel;
        this.dao = dao;
    }

    @SneakyThrows
    @ServiceActivator(inputChannel = "vmsTmsChannel")
    public void processMessage(Message<Boolean> message) {
        if (!prop.isRetry()) {
            log.debug("Retry of PENDING request not enabled, shutting down retry process...");
            return;
        }
        List<TMSModel> records = dao.retrieveAllPendingRequest();
        if (!records.isEmpty()) {
            log.info("Started processing {} records.", records.size());
            records.stream().filter(Objects::nonNull).forEach(record ->
            {
                int retryCount = record.getRetryCount();
                String source = Constants.VMS;
                String mode = record.getType();
                String rrn = record.getRrn();
                MDC.put(Constants.LOG_ID, String.format("%s-%s-%s", source, mode, rrn));
                String payload = record.getPayload();
                if(mode.equalsIgnoreCase(Constants.ERIF) && payload.getBytes(StandardCharsets.UTF_8).length>prop.getErifSize()) {
                	payload = StringUtils.trim(payload);
                }else if(mode.equalsIgnoreCase(Constants.MRIF) && payload.getBytes(StandardCharsets.UTF_8).length>prop.getMrifSize()){
                	payload = StringUtils.trim(payload);
                }
                log.info("Payload after trimming extra spaces...{}, length: {}", payload, payload.getBytes(StandardCharsets.UTF_8).length);
                retryCount++;
                record.setRetryCount(retryCount);
                try {
                    log.info("publishing to new tms queue...");
                    String queue = mode.equalsIgnoreCase(Constants.ERIF) ? prop.getTmsErif() : prop.getTmsMrif();
                    log.info("pushing message to {} queue", queue);
                    connector.produceMessageRabbit(payload, queue, prop.getTmsExchange());
                    record.setStatus(Constants.COMPLETED);
                } catch (AmqpException | JmsException ex) {
                    String var = "Exception while connecting to tms RabbitMQ";
					if (retryCount >= prop.getRetryCount()) {
						record.setStatus(Constants.COMPLETED_WITH_ERROR);
						var = "Message Processing completed with error after max retries.";
					}
					logAndSendEmail(payload, mode, source, rrn, ex,var);	
                } catch (Exception ex) {
                    logAndSendEmail(payload, mode, source, rrn, ex, "Exception while reprocessing records.");
                }
            });
            dao.batchUpdate(records);
            log.debug("Completed processing records.");
        }
    }

    public void processPushMessage(String payload, String mode, String source, String rrn) {
        MDC.put(Constants.LOG_ID, String.format("%s-%s-%s", source, mode, rrn));
        if(mode.equalsIgnoreCase(Constants.ERIF) && payload.getBytes(StandardCharsets.UTF_8).length>prop.getErifSize()) {
        	payload = StringUtils.trim(payload);
        }else if(mode.equalsIgnoreCase(Constants.MRIF) && payload.getBytes(StandardCharsets.UTF_8).length>prop.getMrifSize()){
        	payload = StringUtils.trim(payload);
        }
        log.info("Payload after trimming extra spaces...{}, length: {}", payload, payload.getBytes(StandardCharsets.UTF_8).length);
        if (payload.contains("\"")) {
            payload = payload.replaceAll("\"", "");
        }
        try {
            log.debug("publishing to new tms queue...");
            String queue = mode.equalsIgnoreCase(Constants.ERIF) ? prop.getTmsErif() : prop.getTmsMrif();
            log.debug("pushing message to {} queue", queue);
            connector.produceMessageRabbit(payload, queue, prop.getTmsExchange());
            log.debug("Completed processing message.");
        } catch (AmqpException | JmsException ex) {
            String var = "Exception while connecting to tms RabbitMQ";
            logAndSendEmail(payload, mode, source, rrn, ex, var);
            throw ex;
        } catch (Exception ex) {
            logAndSendEmail(payload, mode, source, rrn, ex, "Exception while reprocessing tms message.");
            throw ex;
        }
    }

    private void logAndSendEmail(String payload, String mode, String source, String rrn, Exception ex, String var) {
        log.error(var);
        log.error(ExceptionUtils.getStackTrace(ex));
        if (prop.isSendEmail()) {
            Exception e = new Exception(var, ex);
            exceptionChannel
                    .send(MessageBuilder.withPayload(e).setHeader(Constants.PAYLOAD, SecurityUtils.encrypt(payload))
                            .setHeader(Constants.SOURCE_HEADER, source).setHeader(Constants.RRN_HEADER, rrn)
                            .setHeader(Constants.MODE_HEADER, mode).build());
        }
    }
}
