package com.incomm.vms.tms.component;

import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

/**
 * @author afilegbe
 */
@Slf4j
@Service
@Scope("prototype")
public class TmsConnector {
    private final RabbitTemplate rabbitTemplate;
    
    public TmsConnector(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    @SneakyThrows
    public void produceMessageRabbit(Object payload, String queue, String exchange) {
        rabbitTemplate.convertAndSend(exchange, queue, payload);
        log.info("Message pushed to rabbitMQ queue with name {} ", queue);
    }

}
