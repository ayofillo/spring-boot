package com.incomm.vms.tms.config;

import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;
import org.springframework.integration.annotation.InboundChannelAdapter;
import org.springframework.integration.annotation.Poller;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.channel.ExecutorChannel;
import org.springframework.integration.core.MessageSource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.GenericMessage;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import javax.sql.DataSource;
import java.util.Properties;

/**
 * @author afilegbe
 */
@Configuration
@EnableJms
public class AppConfig {

    private final Props props;
    private ThreadPoolTaskExecutor threadPoolTaskExecutor;

    public AppConfig(Props prop, ThreadPoolTaskExecutor threadPoolTaskExecutor) {
        this.props = prop;
        this.threadPoolTaskExecutor = threadPoolTaskExecutor;
    }


    @Bean
    public MessageChannel amqpEntryChannel() {
        return new DirectChannel();
    }

    @Bean
    public MessageChannel vmsTmsChannel() {
        return new ExecutorChannel(threadPoolTaskExecutor);
    }

    @Bean
    public MessageChannel emailSendingChannel() {
        return new ExecutorChannel(threadPoolTaskExecutor);
    }

    @Bean
    public MessageChannel exceptionChannel() {
        return new ExecutorChannel(threadPoolTaskExecutor);
    }

    @Bean
    public MessageChannel errorChannel() {
        return new ExecutorChannel(threadPoolTaskExecutor);
    }

    /**
     * Configuring the mailSender
     *
     * @return instance of JavaMailSender
     */
    @Bean
    @Scope("prototype")
    public JavaMailSender javaMailSender() {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        Properties prop = mailSender.getJavaMailProperties();
        prop.put("mail.debug", "false");
        prop.put("mail.transport.protocol", "smtp");
        mailSender.setHost(props.getSmtpHost());
        mailSender.setPort(props.getSmtpPort());

        return mailSender;
    }

    @Bean
    public AmqpTemplate rabbitMqTemplate(ConnectionFactory connectionFactory) {
        return new RabbitTemplate(connectionFactory);
    }

    @Bean
    @InboundChannelAdapter(value = "vmsTmsChannel", poller = @Poller(fixedDelay = "${poller.frequency:5000}"))
    public MessageSource<Boolean> pollerMessageSource() {
        return () -> new GenericMessage<>(true);
    }

    @Bean
    @Primary
    public DataSource dataSource() {
        DriverManagerDataSource ds = new DriverManagerDataSource();
        ds.setDriverClassName(props.getDriverClassName());
        ds.setUrl(props.getDatasourceUrl());
        ds.setUsername(props.getDatasourceUserName());
        ds.setPassword(props.getDatasourcePassword());
        return ds;
    }


    @Bean
    public JdbcTemplate jdbcTemplate(@Qualifier("dataSource") DataSource ds) {
        return new JdbcTemplate(ds);
    }
}
