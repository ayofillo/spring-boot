package com.incomm.vms.tms.config;

/**
 * @author afilegbe
 */
public class Constants {
    private Constants() {}

    public static final String VMS = "vms";
    public static final String GC = "greencard";
    public static final String CSD = "csd";
    public static final String ERIF = "erif";
    public static final String MRIF = "mrif";
    public static final String PAYLOAD = "payload";
    public static final String MODE_HEADER = "x-tms-mode";
    public static final String SOURCE_HEADER = "x-tms-source";
    public static final String RRN_HEADER = "x-tms-rrn";
    public static final String LOG_ID = "logId";
    public static final String COMPLETED = "COMPLETED";
    public static final String COMPLETED_WITH_ERROR = "COMPLETED_WITH_ERROR";
}
