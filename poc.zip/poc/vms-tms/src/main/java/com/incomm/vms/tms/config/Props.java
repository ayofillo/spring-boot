package com.incomm.vms.tms.config;

import lombok.Getter;
import lombok.Setter;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.net.InetAddress;

@RefreshScope
@Configuration
@Component
@Getter
@Setter
public class Props {

    @Value(value = "${spring.mail.host:host}")
    private String smtpHost;
    @Value(value = "${spring.mail.port:80}")
    private Integer smtpPort;
    @Value(value = "${vms.toEmail:to}")
    private String toEmail;
    @Value(value = "${vms.fromEmail:from}")
    private String fromEmail;
    @Value(value = "${vms.img:img}")
    private String imgPath;
    @Value(value = "${vms.env:local}")
    private String env;
    @Value(value = "${vms.sendEmail:false}")
    private boolean sendEmail;

    @Value(value = "${vms.doRetry:false}")
    private boolean retry;

    @Value("${vms.tms.queue:queue}")
    private String vmsTmsQueue;
    @Value("${vms.tms.exchange:exchange}")
    private String vmsExchange;
    @Value("${vms.tms.fetch:1}")
    private int queueFetch;
    @Value("${vms.tms.consumer:5}")
    private int queueConsumer;

    //tms configuration
    @Value("${vms.tms.rabbit.queue.erif:erif}")
    private String tmsErif;
    @Value("${vms.tms.rabbit.queue.mrif:mrif}")
    private String tmsMrif;
    @Value("${vms.tms.rabbit.queue.exchange:exchange}")
    private String tmsExchange;
   
    @Value("${vms.tms.mrif.messageBytes:1329}")
    private int mrifSize;
    
    @Value("${vms.tms.erif.messageBytes:1581}")
    private int erifSize;
  
    @Value("${vms.tms.retryCount:5}")
    private int retryCount;
    @Value("${spring.datasource.driverClassName:oracle.jdbc.driver.OracleDriver}")
    private String driverClassName;

    @Value("${spring.datasource.url:localhost}")
    private String datasourceUrl;

    @Value("${spring.datasource.username:username}")
    private String datasourceUserName;

    @Value("${spring.datasource.password:password}")
    private String datasourcePassword;

    public String getHostName() {
        return InetAddress.getLoopbackAddress().getHostName();
    }
}
