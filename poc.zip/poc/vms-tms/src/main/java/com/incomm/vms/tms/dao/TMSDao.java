package com.incomm.vms.tms.dao;

import java.util.ArrayList;
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.incomm.vms.tms.config.Props;
import com.incomm.vms.tms.model.dao.TMSModel;

import lombok.extern.slf4j.Slf4j;

/**
 * @author afilegbe
 */
@Repository
@Slf4j
public class TMSDao {
	
    private final JdbcTemplate jdbcTemplate;
    private final Props prop;

    public TMSDao(JdbcTemplate jdbcTemplate, Props prop) {
        this.jdbcTemplate = jdbcTemplate;
        this.prop = prop;
    }

    public List<TMSModel> retrieveAllPendingRequest() {
    	try {
	        String sql = "SELECT" +
	                " FN_DMAPS_MAIN(CPM_TRANSACTION_MSG) payload, " +
	                " CPM_PRM_TYPE type, " +
	                " CPM_STATUS status, " +
	                " CPM_RRN rrn,  " +
	                " CPM_INST_DATE insertDate, " +
	                " CPM_RETRY_COUNT retryCount  " +
	                " FROM " +
	                " CMS_PRM_MSGLOGGER  " +
	                " WHERE " +
	                " CPM_STATUS = 'PENDING'  " +
	                " AND rownum < 50  " +
	                " AND CPM_RETRY_COUNT < ? " +
	                " ORDER BY CPM_INST_DATE " +
	                " FOR UPDATE skip locked";
	        return new ArrayList<>(jdbcTemplate.query(sql, new Object[] {prop.getRetryCount()}, new BeanPropertyRowMapper<>(TMSModel.class)));
    	}catch(Exception ex) {
    		log.error("Exception while retrieving records from db.", ex);
    	}
    	return new ArrayList<>();
    }

    public void batchUpdate(List<TMSModel> models) {
    	try {
	        if(!models.isEmpty()) {
		        String sql = "UPDATE CMS_PRM_MSGLOGGER SET CPM_STATUS = ?, " +
		                "CPM_RETRY_COUNT = ?, CPM_UPDATE_DATE = SYSDATE " +
		                "WHERE CPM_RRN = ? and CPM_INST_DATE = ? ";
		        jdbcTemplate.batchUpdate(sql, models, 1000, (ps, model) -> {
		            ps.setString(1, model.getStatus());
		            ps.setInt(2, model.getRetryCount());
		            ps.setString(3, model.getRrn());
		            ps.setDate(4, model.getInsertDate());
		        });
	        }
    	}catch(Exception ex) {
    		log.error("Exception while batch updating records", ex);
    		throw ex;
    	}
    }
    
    
}
