package com.incomm.vms.tms.model.dao;

import java.sql.Date;

import com.google.gson.Gson;
import lombok.Data;

/**
 * @author afilegbe
 */
@Data
public class TMSModel {
    private String payload;
    private String type;
    private String rrn;
    private String status;
    private Integer retryCount;
    private Date insertDate;
    private String source;

    @Override
    public String toString() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }
}
