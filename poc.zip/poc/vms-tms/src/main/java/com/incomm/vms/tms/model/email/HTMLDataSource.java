package com.incomm.vms.tms.model.email;

import javax.activation.DataSource;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * @author afilegbe
 * @since v1.0
 */
public class HTMLDataSource implements DataSource {

    private final String html;

    public HTMLDataSource(String htmlString) {
        html = htmlString;
    }

    // Return html string in an InputStream.
    // A new stream must be returned each time.
    @Override
    public InputStream getInputStream() throws IOException {
        if (html == null) {
            throw new IOException("Null HTML");
        }
        return new ByteArrayInputStream(html.getBytes());
    }

    @Override
    public OutputStream getOutputStream() throws IOException {
        throw new IOException("This DataHandler cannot write HTML");
    }

    @Override
    public String getContentType() {
        return "text/html";
    }

    @Override
    public String getName() {
        return "JAF text/html dataSource to send e-mail only";
    }
}

