package com.incomm.vms.tms.model.email;

import com.google.gson.Gson;
import lombok.Data;

import javax.xml.bind.annotation.XmlRootElement;
import java.io.Serializable;

/**
 * @author afilegbe
 */
@XmlRootElement
@Data
public class OutgoingEmail implements Serializable {

    private static final long serialVersionUID = 8748869645923431013L;
    private String toEmail;
    private String fromEmail;
    private String subject;
    private String body;
    private String attachmentFileName;
    private String timeStamp;
    private String fileName;

    @Override
    public String toString() {
        Gson gson = new Gson();
        return gson.toJson(this);
    }
}

