package com.incomm.vms.tms.util;

import java.net.UnknownHostException;
import java.util.Random;

public final class ContentIdGenerator {

    private ContentIdGenerator() {
    }

    private static int seq = 0;
    private static String hostName;
    private static final int MULTIPLIER = 100000;

    static {
        try {
            hostName = java.net.InetAddress.getLocalHost().getCanonicalHostName();
        } catch (UnknownHostException e) {
            // we can't find our hostname? okay, use something no one else is likely to use
            hostName = new Random(System.currentTimeMillis()).nextInt(MULTIPLIER) + ".localhost";
        }
    }

    /**
     * Sequence goes from 0 to 100K, then starts up at 0 again. This is large
     * enough, and saves
     *
     * @return sequential generated value
     */
    private static synchronized int getSeq() {
        return (seq++) % MULTIPLIER;
    }

    /**
     * One possible way to generate very-likely-unique content IDs.
     *
     * @return A content id that uses the hostname, the current time, and a
     * sequence number to avoid collision.
     */
    public static String getContentId() {
        return getSeq() + "." + System.currentTimeMillis() + "@" + hostName;
    }
}
