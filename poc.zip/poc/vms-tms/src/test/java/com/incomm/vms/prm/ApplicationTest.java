package com.incomm.vms.prm;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import com.incomm.vms.tms.VMSTMSApplication;
import com.incomm.vms.tms.model.dao.TMSModel;

/**
 * @author afilegbe
 */
@SpringBootTest(classes={VMSTMSApplication.class})
@AutoConfigureMockMvc
@Slf4j
public class ApplicationTest {

    public static final String DECRYPT_PAYLOAD = "VMS(CPjUoZVajEtjT+8gAp6HvMbOX9lbhFIZ+fIVV3P0v4fGzl/ZW4RSGfnyFVdz9L+HkX3OxHMpcD8e\n" +
            "rYy6eXIPQ2iC/5O2+j7Ndw3sRhWWlT1ZBeuBWD9PhaPstKWAtHx5/NyNSjiAsnrQ9GMCRFdF8/jR\n" +
            "PXxce1Wfmui9NuYR9dEF13V19HHophZ60MNEpLiXaCSDubU1CM13NmdUmB3wJx1SJ5QgEZIKtxxA\n" +
            "JdfHzxSqEpOXjYqmHFi1o3hwN9Byaas3j0KwoMsefmwf2MuucqvXXPMIld4k6r06boLJYEGz1bLR\n" +
            "esWwJHgBJ1mSZZrg9koegIwiztmQ2wwgDw6My9ydsiJOHszstqY9d5WYu35e6BT1jYxkPi/44TNp\n" +
            "BqOv/amUpLHOtrXmW8db84SK98bOX9lbhFIZ+fIVV3P0v4fGzl/ZW4RSGfnyFVdz9L+HQqjGtg0S\n" +
            "alkY4lC+Uzg/AsbOX9lbhFIZ+fIVV3P0v4fGzl/ZW4RSGfnyFVdz9L+H05kKWoIT6BI6VKQOLFjP\n" +
            "Q8bOX9lbhFIZ+fIVV3P0v4fGzl/ZW4RSGfnyFVdz9L+Hxs5f2VuEUhn58hVXc/S/h8bOX9lbhFIZ\n" +
            "+fIVV3P0v4fKtgFKMk5oMhdmhCuOMC58xs5f2VuEUhn58hVXc/S/h8bOX9lbhFIZ+fIVV3P0v4fG\n" +
            "zl/ZW4RSGfnyFVdz9L+Hxs5f2VuEUhn58hVXc/S/h8bOX9lbhFIZ+fIVV3P0v4fGzl/ZW4RSGfny\n" +
            "FVdz9L+Hxs5f2VuEUhn58hVXc/S/h8bOX9lbhFIZ+fIVV3P0v4eXPIBF4PKPH9eU59V2ARdU4IaC\n" +
            "vl8rGKboQ3oVsRDUGOCGgr5fKxim6EN6FbEQ1BiNpm2Nvid2G9Q6X1k+05TUxs5f2VuEUhn58hVX\n" +
            "c/S/h8bOX9lbhFIZ+fIVV3P0v4fGzl/ZW4RSGfnyFVdz9L+Hxs5f2VuEUhn58hVXc/S/h8bOX9lb\n" +
            "hFIZ+fIVV3P0v4fGzl/ZW4RSGfnyFVdz9L+Hxs5f2VuEUhn58hVXc/S/h8bOX9lbhFIZ+fIVV3P0\n" +
            "v4fGzl/ZW4RSGfnyFVdz9L+Hxs5f2VuEUhn58hVXc/S/h8bOX9lbhFIZ+fIVV3P0v4fGzl/ZW4RS\n" +
            "GfnyFVdz9L+Hxs5f2VuEUhn58hVXc/S/h8bOX9lbhFIZ+fIVV3P0v4fGzl/ZW4RSGfnyFVdz9L+H\n" +
            "xs5f2VuEUhn58hVXc/S/h8bOX9lbhFIZ+fIVV3P0v4fGzl/ZW4RSGfnyFVdz9L+HlzyAReDyjx/X\n" +
            "lOfVdgEXVOCGgr5fKxim6EN6FbEQ1BjghoK+XysYpuhDehWxENQY37d7Ewphb1+yQV/yibnc4Ean\n" +
            "XA7uwk45I4fgLmGBzpHGzl/ZW4RSGfnyFVdz9L+Hxs5f2VuEUhn58hVXc/S/h8bOX9lbhFIZ+fIV\n" +
            "V3P0v4fGzl/ZW4RSGfnyFVdz9L+Hxs5f2VuEUhn58hVXc/S/h8bOX9lbhFIZ+fIVV3P0v4fGzl/Z\n" +
            "W4RSGfnyFVdz9L+Hxs5f2VuEUhn58hVXc/S/h8bOX9lbhFIZ+fIVV3P0v4ddY6ryMYw/uHSdq1Nw\n" +
            "X0gr4IaCvl8rGKboQ3oVsRDUGOCGgr5fKxim6EN6FbEQ1BjghoK+XysYpuhDehWxENQY4IaCvl8r\n" +
            "GKboQ3oVsRDUGIjld5F3xtSHbbXKScf4DKKXPIBF4PKPH9eU59V2ARdUZ7xigwp4TDL7HsCQoS8o\n" +
            "8wURZ3x6s2X7o1e0Z9J5NKE=)";
    private static final String erif = "ERIF705456601000001640470 VMS        011002202004291431440020200429545660      OR000001178700              0000000001000000000000000000000000000000000000000000000000001110   162508000     1                                                    2                   599900000000                            MERCHANT NAME DBA        MERCHANT CITY   GBR      0000000000000000000000000000000000000001000000000000000100000000000000000000000000000000000000000000000000       OLSN          0840   0 0 000000000                                0000000000000000000000000000000000 6610000000000223                                                                                                                    X 20200421202004290000000000000000000000000000000000000000001 12379050733   840                                                      000                                                      000                                                      000                                            00000000000000000000           000000000003500000000020000000000016500A GIFT FOR YOU                                              19000101                                                                                                                                                    *                                                                              **                                                         GA US*                           *                                                                                  2020042902315555        000000000000 0 0000 TAIL";
    private static final String mrif = "MERC70NOBILL002                                        5456601000001640476545660XXXXXX    V 1210090120200429164836000000000003298384233752  88    00000002000000000002000000000000000000008384233752             545660100000164     H1210162994  Suc1      840     0000                    779961          1                                         22222                                      Sheetz Incorp                                                                   NOBILL002    00                                                                                                                                    000000000000000000000000000000000000000000000000      SPIL                                                                                                                                                                                                                                                                                                      000000000000000000000000000000000000000000000000            00000000                                                                                                                                                                000000000000000000000000000000000000000000000000000000000000000000000000000000000000        00000000000000 0000                    TAIL";
    public static TMSModel ERIF_PAYLOAD, MRIF_PAYLOAD;
    @Autowired
    public MockMvc mockMvc;

    @BeforeEach
    public void init() {
        ERIF_PAYLOAD = new TMSModel();
        ERIF_PAYLOAD.setPayload(erif);

        MRIF_PAYLOAD = new TMSModel();
        MRIF_PAYLOAD.setPayload(mrif);
    }

}
