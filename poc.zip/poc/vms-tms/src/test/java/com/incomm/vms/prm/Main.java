package com.incomm.vms.prm;

import com.google.gson.Gson;
import lombok.Data;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import java.util.Collections;

/**
 * @author afilegbe
 */
public class Main {
    public static void main(String[] args) {
        String msg = "gjdjfh\r\n";
        System.out.println(msg);
        System.out.println("before");
        System.out.println(msg.trim());
        System.out.println("After");
        System.out.println(msg);
        System.out.println("before");

        String payload = "\"ERIF704420621000001666059 VMS        121002202008271029220020200827442062      " +
                "OQ00000009A200              0000000005000000000000000000000000000000000000000000000000001210   " +
                "589415000     1                                                    2                   599900000000   " +
                "                         Academy sports                           USA      " +
                "0000000000000000000000000000000000000005000000000000000000000000000000000000000000000000000000000000000000 " +
                "      OLSD          0840   0 0 000000000                                " +
                "0000000000000000000000000000000000 0620000065008                                     " +
                "                                                                                  " +
                "M 20200706202007130000000000000000000000000000000000000000001 06200000650   840                          " +
                "                            000                                                      000                                                      000                                            00000000000000000000           000000000012710000000012910000000000200CLARK                                                       19571205                                                                                                                                                    81 Flat Rock                                                                    SanFrancisco                                              CA US9111 rdf3                                                 " +
                " 7713929999                         test@incomm.com  2020082710293937        000000000000 0 0000 TAIL\\r\\n\"";
        System.out.println(payload);
        System.out.println(payload.contains("\""));
        System.out.println(payload.replaceAll("\"", ""));

        for(int i = 0; i<1000; i++){
            sendPRMRequest(System.currentTimeMillis()+"", payload);
        }
    }
    private static final String MODE_HEADER = "x-tms-mode";
    private static final String SOURCE_HEADER = "x-tms-source";
    private static final String RRN_HEADER = "x-tms-rrn";
    private static boolean sendPRMRequest(String rrn, String request) {
         try {
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            headers.setAccept(Collections.singletonList(MediaType.APPLICATION_JSON));
            headers.set(MODE_HEADER, "erif");
            headers.set(SOURCE_HEADER, "vms");
            headers.set(RRN_HEADER, rrn);

            PRMModel payload = new PRMModel();
            payload.setPayload(request);
            HttpEntity<String> entity = new HttpEntity<>(payload.toString(), headers);

            RestTemplate restTemplate = new RestTemplate();
            restTemplate.postForObject("http://localhost:7130/publish-message", entity, String.class);

            return true;
        } catch (Exception e) {
            return false;
        }
    }
    @Data
    private static class PRMModel {
        private String payload;

        @Override
        public String toString() {
            Gson gson = new Gson();
            return gson.toJson(this);
        }
    }
}
