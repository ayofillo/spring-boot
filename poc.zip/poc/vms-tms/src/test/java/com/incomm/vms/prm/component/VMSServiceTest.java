package com.incomm.vms.prm.component;

import com.incomm.vms.prm.ApplicationTest;
import com.incomm.vms.tms.api.TMSController;
import com.incomm.vms.tms.component.TMSService;
import com.incomm.vms.tms.component.TmsConnector;
import com.incomm.vms.tms.config.Props;
import com.incomm.vms.tms.dao.TMSDao;
import com.incomm.vms.tms.model.dao.TMSModel;
import lombok.SneakyThrows;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.messaging.support.GenericMessage;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

class VMSServiceTest extends ApplicationTest {
    @Autowired
    private TMSController prmService;

    @MockBean
    private TmsConnector connector;

    @MockBean
    private TMSDao dao;
    
    @Autowired
    private Props props;

//    @SneakyThrows
//    @Test
//    @DisplayName("Process Message Retrieval")
//    void testMessageRetrieval() {
//        prmService.processMessage(null);
//    }


    @SneakyThrows
    @Test
    @DisplayName("Process Message Test")
    void testMessage() {
        List<TMSModel> records = new ArrayList<>();
        TMSModel model = new TMSModel();
        model.setInsertDate(new Date(0));
        model.setType("ERIF");
        model.setPayload("ERIF704999401000001233329 VMS        011011202010261022120020201026499940      est20201026380              0000000003000000000000000000000000000000000000000000000000000210   849464 000                                                         05000000000000005       5000000000000005                                                              US                000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000       DFCC          0000   0 0 000000000                                0000000000000000000000000000000000 8210000075470                                    0001                                                                               V 20181101201812070000000000000000000000000000000000000000001 82100000754   840                                                      000                                                      000                                                      000                                            00000000000000000000           000000000041247000000041247000000000000Rashmi                                             12399445019800412                                                                                                                                                    Apt Saint-Léonard Southeast                                                     Montréal                                                  CA USH1S 2J7            1943678516                              4444433336                         test@incomm.com  2020102605295651        000000000000 0 0000 TAIL\\r\\n");
        model.setRetryCount(3);
        model.setRrn("141230081944");
        model.setStatus("PENDING");
        records.add(model);
        int len = model.getPayload().length();
        System.out.println("length before"+len);
        props.setRetry(true);
        Mockito.when(dao.retrieveAllPendingRequest()).thenReturn(records);
        Mockito.doNothing().when(dao).batchUpdate(Mockito.any(List.class));
        Mockito.doNothing().when(connector).produceMessageRabbit(Mockito.any(), Mockito.anyString(), Mockito.anyString());
        prmService.publishToTms(model, model.getRrn(), "ERIF", "vms");
        assertEquals(3, (int) model.getRetryCount());
        System.out.println("length after:"+model.getPayload().length());
        assertEquals(len, (int) model.getPayload().length());
//        assertEquals("COMPLETED", model.getStatus());
    }
}